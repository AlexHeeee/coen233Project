const base = {
    get() {
        return {
            url : "http://localhost:8080/djangoz3gw0/",
            name: "djangoz3gw0",
            indexUrl: ''
        };
    },
    getProjectName(){
        return {
            projectName: "Classroom Reservation System"
        } 
    }
}
export default base
