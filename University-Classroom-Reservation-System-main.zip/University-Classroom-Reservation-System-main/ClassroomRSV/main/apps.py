from django.apps import AppConfig


class MainConfig(AppConfig):
    name = 'main'
    verbose_name = verbose_name_plural = r'list module'
